package repo;

import model.Poliza;
public interface IPolizaRepo extends IGenericRepo<Poliza,Integer>{
}
