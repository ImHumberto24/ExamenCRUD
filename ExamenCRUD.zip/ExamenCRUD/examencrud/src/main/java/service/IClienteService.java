package service;

import model.Cliente;

public interface IClienteService  extends ICRUD<Cliente,Integer>  {
}
