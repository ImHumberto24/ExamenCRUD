package dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)

public class ClienteDTO {
    private Integer idCliente;

    @NotNull
    @Size(min = 4, max = 30)
    private String nombre;

    @NotNull
    @Size(min = 4, max = 30)
    private String apellido;

    @NotNull
    @Size(min = 3, max=3)
    private String tipoDocumento;

    @NotNull
    @Size(min = 8, max=8)
    private String numeroDocumento;

}
