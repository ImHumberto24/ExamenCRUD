package service.impl;

import model.Cliente;
import model.Poliza;
import repo.IGenericRepo;
import repo.IPolizaRepo;
import service.IClienteService;
import service.IPolizaService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class PolizaServiceImpl extends CRUDImpl<Poliza,Integer> implements IPolizaService {
    private final IPolizaRepo repo;

    @Override
    protected IGenericRepo<Poliza, Integer> getRepo() {
        return repo;
    }

}
