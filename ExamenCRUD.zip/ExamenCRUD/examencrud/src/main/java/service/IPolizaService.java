package service;

import model.Poliza;

public interface IPolizaService  extends ICRUD<Poliza,Integer>  {
}
