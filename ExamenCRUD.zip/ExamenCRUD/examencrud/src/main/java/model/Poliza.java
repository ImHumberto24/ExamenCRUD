package model;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Poliza {
    @Id
    private Integer idPoliza;

    @Column(nullable = false, length = 10)
    private String Numero;

    @Column(nullable = false, length = 8)
    private Date fechaInicio;

    @Column(nullable = false, length = 8)
    private Date fechaFin;

    @Column(nullable = false)
    private Integer idCliente;

}
