package repo;
import model.Cliente;
import model.Poliza;

public interface IClienteRepo  extends IGenericRepo<Cliente,Integer> {
}
