package service.impl;

import model.Cliente;
import repo.IGenericRepo;
import repo.IClienteRepo;
import service.IClienteService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class ClienteServiceImpl extends CRUDImpl<Cliente,Integer> implements IClienteService  {
    private final IClienteRepo repo;

    @Override
    protected IGenericRepo<Cliente, Integer> getRepo() {
        return repo;
    }

}
