package service;

import model.Cliente;

import java.util.List;

public interface ICRUD<T,ID>  {
    T save(T t);
    T update(Integer id, Cliente t);
    List<T> findAll();
    T findById(ID id);
    void delete(ID id);

}
