package service.impl;

import exception.ModelNotFoundException;
import repo.IGenericRepo;
import service.ICRUD;

import java.util.List;
public abstract class CRUDImpl<T,ID> implements ICRUD<T,ID>  {

    protected abstract IGenericRepo<T,ID> getRepo();


}
