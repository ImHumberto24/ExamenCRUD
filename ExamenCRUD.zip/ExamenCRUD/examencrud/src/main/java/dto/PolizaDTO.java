package dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)

public class PolizaDTO {
    private Integer idPoliza;

    @NotNull
    @Size(min = 6, max = 10)
    private String Numero;

    @NotNull
    @Size(min = 8, max = 8)
    private String fechaInicio;

    @NotNull
    @Size(min = 8, max = 8)
    private String fechaFin;

    private Integer idCliente;
}
