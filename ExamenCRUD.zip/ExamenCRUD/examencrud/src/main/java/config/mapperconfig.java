package config;

import org.modelmapper.ModelMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class mapperconfig {
    @Bean(name = "defaultMapper")
    public ModelMapper defaultMapper(){
        return new ModelMapper();
    }

    @Bean(name = "polizaMapper")
    public ModelMapper polizaMapper(){

        ModelMapper mapper = new ModelMapper();

        return mapper;
    }

    @Bean(name = "clienteMapper")
    public ModelMapper clienteMapper(){

        ModelMapper mapper = new ModelMapper();

        return mapper;
    }

}
