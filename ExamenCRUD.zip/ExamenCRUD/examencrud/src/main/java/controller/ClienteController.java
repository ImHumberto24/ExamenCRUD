package controller;

import dto.GenericResponse;
import dto.ClienteDTO;
import model.Cliente;
import service.IClienteService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.Arrays;
import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/cliente")

public class ClienteController {

    private final IClienteService service;
    @Qualifier("defaultMapper")
    private final ModelMapper modelMapper;

    @GetMapping
    public ResponseEntity<GenericResponse<ClienteDTO>> getAllClientes(){
        List<ClienteDTO> list = service.findAll().stream().map(this::convertToDto).toList();
        return ResponseEntity.ok(new GenericResponse<>(200,"success",list));
    }

    @GetMapping("/{id}")
    public ResponseEntity<GenericResponse<ClienteDTO>> getClienteById(@PathVariable("id") int id){
        Student obj = service.findById(id);
        return ResponseEntity.ok(new GenericResponse<>(200,"success", Arrays.asList(convertToDto(obj))));
    }

    @PostMapping
    public ResponseEntity<Void> save(@Valid @RequestBody ClienteDTO dto){
        Cliente obj = service.save(convertToEntity(dto));
        URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(obj.getIdCliente()).toUri();
        return ResponseEntity.created(location).build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<GenericResponse<ClienteDTO>> update(@PathVariable("id") Integer id,@Valid @RequestBody  ClienteDTO dto){
        Student obj = service.update(id,convertToEntity(dto));
        return ResponseEntity.ok(new GenericResponse<>(200,"success",Arrays.asList(convertToDto(obj))));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable("id") int id){
        service.delete(id);
        return ResponseEntity.noContent().build();
    }


    private ClienteDTO convertToDto(Student obj){
        return modelMapper.map(obj, ClienteDTO.class);
    }

    private Cliente convertToEntity(ClienteDTO obj){
        return modelMapper.map(obj,Cliente.class);
    }
}
